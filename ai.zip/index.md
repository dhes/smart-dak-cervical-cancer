# Home - WHO SMART DAK — Cervical Cancer Screening (L2) v0.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:https://dhes.github.io/smart-dak-cervical-cancer/ImplementationGuide/dhes.dak.cervical-cancer | *Version*:0.1.0 |
| Draft as of 2026-04-24 | *Computable Name*:CervicalCancerDAK |

**Status and Maturity**

This implementation guide is a **draft** (version 0.1.0, CI build) at **FHIR Maturity Model (FMM) level 0** — initial, pre-implementation. The content has not undergone WHO SMART Guidelines submission, has not been reviewed by clinical subject-matter experts, and all register entries are in `proposed` status. Material changes are expected in subsequent versions until the first formally-released version is cut.

**Versioning policy**

This IG follows [Semantic Versioning 2.0.0](https://semver.org/spec/v2.0.0.html): `major.minor.patch`. All FHIR artifacts defined in the IG inherit the IG's version number. Material changes to any artifact trigger a patch bump; backwards-incompatible changes trigger a major bump. See the [Change Log](changes.md) for version history.

This implementation guide presents Layer 2 (decision logic) artifacts for cervical cancer screening, modelling **Algorithm 5** (HPV DNA primary screening with VIA triage) from the [WHO 2021 Cervical Cancer Screening Guideline (2nd ed.)](https://www.who.int/publications/i/item/9789240030824).

### What this IG contains

This IG publishes the L2 artifacts of a cervical cancer screening Digital Adaptation Kit (DAK), repackaging the WHO 2021 guideline using textualist and purposive interpretive strategies:

* **Interpretation Register** — 8 entries documenting every interpretive decision made in translating the WHO guideline narrative (L1) into decision logic (L2). Each entry records the options considered, the option selected, and the rationale.
* **Core Data Dictionary** — 19 data elements covering every input and output of the decision logic, with linkages to harvested elements from existing WHO SMART DAKs (HIV, ANC, Immunizations).
* **Decision Logic** — Two parallel DMN (Decision Model and Notation) artifacts: a **textualist** version faithful to the guideline language, and a **purposive** version encoding the interpretive resolutions from the register.
* **Algorithm Selection Analysis** — A recommendation-by-recommendation walk-through of how the WHO guideline narrows the choice from seven candidate algorithms to Algorithm 5 for countries with the epidemiological profile described in the scope declaration.

### What this IG does not contain

**L3 (FHIR) artifacts are not yet authored.** This IG does not include FHIR profiles, CQL decision-support libraries, terminology bindings, or value sets. These are deferred to a future L3 authoring pass. The L2 artifacts are designed to be L3-ready: the Core Data Dictionary carries explicit L3-stub columns (ICD-11, SNOMED CT, LOINC, FHIR Resource, FHIR Profile, Canonical URI) that are intentionally blank, awaiting binding by a terminology specialist at country adaptation time.

**This is not a clinical recommendation.** The interpretive choices in this DAK belong to a hypothetical jurisdiction exercising a methodology. They are not recommendations for any real screening program. See the [Scope Declaration (cc-000)](cc-000.md) for the full disclaimer and the epidemiological regime the case study assumes.

### Reading order

The IG is organised by reading order, not by entry number. A reader encountering this material for the first time should proceed:

1. **[Algorithm Selection Analysis](algorithm-selection.md)**— Why Algorithm 5, and how the guideline narrows the field
1. **[Scope Declaration (cc-000)](cc-000.md)**— What the DAK models, what it excludes, and the epidemiological regime
1. **[Register overview](register.md)**— The interpretation register catalogue and reading guide
1. **Foundation clinical decisions**—[cc-002](cc-002.md),[cc-003](cc-003.md),[cc-004](cc-004.md)
1. **Specification**—[cc-005](cc-005.md)(screening interval resolution)
1. **Population and inclusion**—[cc-001](cc-001.md)
1. **Inferences over silences**—[cc-006](cc-006.md),[cc-007](cc-007.md)
1. **[Data Dictionary](dictionary.md)**and**[Decision Logic](decision-logic.md)**

### Background

This DAK repackages and integrates the WHO 2021 Cervical Cancer Screening Guideline into L2 artifacts per [Section 3.1 of the WHO SMART Guidelines IG Starter Kit](https://smart.who.int/ig-starter-kit/l2_dak_authoring.html). The interpretive choices made during repackaging are documented as register entries (`cc-000` through `cc-008`); the two interpretive strategies applied — textualist and purposive — are explained on the [Methodology](methodology.md) page.

### Status

This is a **draft** publication (version 0.1.0). All register entries are in `proposed` status. The DMN artifacts have been tested against Camunda 8.8 but have not been reviewed by clinical subject-matter experts.

